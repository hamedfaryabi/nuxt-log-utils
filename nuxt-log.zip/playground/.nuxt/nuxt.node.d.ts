/// <reference types="nuxt-log" />
/// <reference types="@nuxt/devtools" />
/// <reference types="@nuxt/telemetry" />
/// <reference path="types/nitro-layouts.d.ts" />
/// <reference path="types/modules.d.ts" />
/// <reference path="types/runtime-config.d.ts" />
/// <reference path="types/app.config.d.ts" />
/// <reference types="nuxt" />
/// <reference path="../../node_modules/.pnpm/@nuxt+vite-builder@4.3.1_@types+node@25.3.0_eslint@10.0.1_jiti@2.6.1__magicast@0.5.2_nu_5a3a1e47cea7c3ba45fdc4a9db088cd1/node_modules/@nuxt/vite-builder/dist/index.d.mts" />
/// <reference path="../../node_modules/.pnpm/@nuxt+nitro-server@4.3.1_db0@0.3.4_ioredis@5.9.3_magicast@0.5.2_nuxt@4.3.1_@parcel+watc_01c4fd20000136010b2776c207351151/node_modules/@nuxt/nitro-server/dist/index.d.mts" />
/// <reference path="types/nitro-middleware.d.ts" />
/// <reference path="schema/nuxt.schema.d.ts" />

export {}
